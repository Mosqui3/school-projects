/**
 * The TextQuilt class allows to physically represent a quilt
 * through the corresponding pieces' texture and orientation.
 *
 * @author Oscar Martinez Vega
 */

public class TextQuilt extends Quilt
{
    public String quiltToText(Quilt aQuilt)
    {
    	String textQuilt = "";
    	String RawQuilt = aQuilt.toRawString();
    	String row = RawQuilt.substring(0, aQuilt.getColumns()*2);
		while(RawQuilt.isEmpty() == false)
		{
			row = RawQuilt.substring(0, aQuilt.getColumns()*2);
			String topRow = "";
			String bottomRow = "";
			while(row.isEmpty() == false)
			{
				String piece = row.substring(0, 2);
				switch(piece)
				{
					case "a0":
						topRow = topRow + "'`";
						bottomRow = bottomRow + "``";
						break;
					case "a1":
						topRow = topRow + "`'";
						bottomRow = bottomRow + "``";
						break;
					case "a2":
						topRow = topRow + "``";
						bottomRow = bottomRow +	"`'";	
						break;
					case "a3":
						topRow = topRow + "``";
						bottomRow = bottomRow + "'`";
						break;
					case "b0":
						topRow = topRow + "%#";
						bottomRow = bottomRow + "##";
						break;
					case "b1":
						topRow = topRow + "#%";
						bottomRow = bottomRow + "##";
						break;
					case "b2":
						topRow = topRow + "##";
						bottomRow = bottomRow + "#%";
						break;
					case "b3":
						topRow = topRow + "##";
						bottomRow = bottomRow + "%#";
						break;
					default:
						System.out.println("Invalid Input!");
				}
				row = row.substring(2);	
			}
			row = RawQuilt.substring(aQuilt.getColumns()*2);
			RawQuilt = RawQuilt.substring(aQuilt.getColumns()*2);
			textQuilt = textQuilt + topRow + "\n" + bottomRow + "\n";
		} 
		return textQuilt;
    }
}
