/**
 * A scarf is a 1-dimensional collection of pieces
 *
 * @author John Coleman
 */

import java.util.ArrayList;
import java.util.Iterator;

public class Scarf implements Iterable<Piece>
{
    private ArrayList<Piece> scarf;

	    /**
	     * Constructor for objects of class Scarf
	     * @return 
	     */
	    public Scarf(String DNA)
	    {
        	scarf = new ArrayList<Piece>();
        	String[] pieces = DNA.split(",");
	        for(String s:pieces){
	            String texture = s.substring(0,1);
	            int orientation = Integer.parseInt(s.substring(1,2));
	            scarf.add(new Piece(texture,orientation));
	        }
	    }
        
        @Override
        public Iterator<Piece> iterator()
        {
            return scarf.iterator();
        }

        void clear()
        {
        	scarf.clear();
        }
        
        void addPiece(Piece p)
        {
            scarf.add(p.copy());
        }
        
        void addScarf(Scarf other_scarf)
        {
           for(Piece p : other_scarf)
           {
               addPiece(p);
           }
        }
        
        public ArrayList<Piece> getScarf()
        {
        	return scarf;
        }
}