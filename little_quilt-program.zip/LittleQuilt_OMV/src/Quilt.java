/**
 * A quilt is a 2-dimensional collection of ArrayList of Pieces.
 * This class allows to loads a quilt through a string (e.g. "a0,b1\nb1,b1").
 * This class also allows to turn, unturn, sew, pile, pinWheel, 
 * repeat, checkerBoard, and toString the quilt.
 *
 * @author Oscar Martinez Vega
 */

import java.util.ArrayList;
import java.util.Collections;

public class Quilt
{
	//Quilt fields
	private ArrayList<ArrayList<Piece>> quilt = new ArrayList<ArrayList<Piece>>();
	private int numRows = 0;
	private int numColumns = 0;
	
	//point f.
	//Transform a string of shape e.g. "a0,b1\na1,b2" to an ArrayList<ArrayList<Piece>>
	@SuppressWarnings("unchecked")
	public ArrayList<ArrayList<Piece>> FromString(String body)
	{
		ArrayList<ArrayList<Piece>> Ex_quilt = new ArrayList<ArrayList<Piece>>();
		Scarf useScarf;
		if (body.contains("\n") == true)
		{
			int splitN = body.indexOf("\n");
			String row = body.substring(0,splitN);			
			while(body.contains("\n"))
			{
				if (body.indexOf("\n") == body.lastIndexOf("\n"))
				{
					useScarf = new Scarf(row);
					Ex_quilt.add((ArrayList<Piece>) useScarf.getScarf().clone());
					useScarf.clear();
					body = body.substring(splitN+1);
				}	
				else
				{
					useScarf = new Scarf(row);
					Ex_quilt.add((ArrayList<Piece>) useScarf.getScarf().clone());
					useScarf.clear();
					body = body.substring(splitN+1);
					splitN = body.indexOf("\n");
					row = body.substring(0,splitN);
				}	
			}
		}
		
		useScarf = new Scarf(body);
		Ex_quilt.add((ArrayList<Piece>) useScarf.getScarf().clone());
		useScarf.clear();
		return Ex_quilt;
	}
	
	//point e.
	//Loads main quilt with an ArrayList<ArrayList<Piece>> [usually obtained by the previous method]
	@SuppressWarnings("unchecked")
	public void FromPieces(ArrayList<ArrayList<Piece>> list)
	{
		quilt = (ArrayList<ArrayList<Piece>>) list.clone();
		numRows = quilt.size();
		for(ArrayList<Piece> r:quilt)
		{
			numColumns = r.size();
		}
	}
	
	//point g.
	//creates a new quilt object of shape ArrayList<ArrayList<Piece>>
	@SuppressWarnings("unchecked")
	public ArrayList<ArrayList<Piece>> newQuilt(ArrayList<ArrayList<Piece>> list)
	{
		ArrayList<ArrayList<Piece>> quilt2 = new ArrayList<ArrayList<Piece>>();
		quilt2 = (ArrayList<ArrayList<Piece>>) list.clone();
		
		//PART OF CODE NOT USED. Code can be used in the future to raise errors.
		/*int numRows2 = list.size();
		int numColumns2 = 0;
		for(ArrayList<Piece> r:quilt2)
		{
			numColumns2 = r.size();
		}*/
		
		return quilt2;
	}
	
	//getter for numRows
	public int getRows()
	{
		return numRows;
	}
	
	//getter for numColumns
	public int getColumns()
	{
		return numColumns;
	}
	
	//getter for quilt in shape of ArrayList<ArrayList<Piece>>
	public ArrayList<ArrayList<Piece>> getQuilt()
	{
		return quilt;
	}
	
	//updates the number of rows and columns from the size of main quilt
	public void update()
	{
		numRows = quilt.size();
		for(ArrayList<Piece> r:quilt)
		{
			numColumns = r.size();
		}
	}
    
	//turns quilt and rotates every piece in it 90 degrees clockwise
    @SuppressWarnings("unchecked")
	public void turn() 
    {
    	//Transpose quilt
    	ArrayList<ArrayList<Piece>> matrixOut = new ArrayList<ArrayList<Piece>>();
        if (!quilt.isEmpty()) 
        {
            int noOfElementsInList = numColumns;
            for (int i = 0; i < noOfElementsInList; i++) 
            {
            	ArrayList<Piece> col = new ArrayList<Piece>();
                for (ArrayList<Piece> row : quilt) 
                {
                    col.add(row.get(i));
                }
                matrixOut.add(col);
            }
        }
        
        quilt = (ArrayList<ArrayList<Piece>>) matrixOut.clone();
        
        update();
		
        //swap columns to complete turn algorithm
		int rowLen = numColumns;
		for(ArrayList<Piece> row : quilt)
		{
			int first = 0;
			int last = rowLen-1;
			for(int i = 1; i <= rowLen/2; i++)
			{
				Collections.swap(row,first,last);
				first++;
				last--;					
			}
		}
		
		//rotates 90 degrees every piece in quilt
		for(ArrayList<Piece> row : quilt)
		{
			for(Piece p: row)
			{
				p.rotate();
			}
		}
    }
    
    //turns quilt and rotates every piece in it 90 degrees counterclockwise
    public void unturn()
    {
    	for(int i = 0; i<3; i++)
    	{
    		turn();	
    	}
    }
    
    //prints quilt as a string of pieces in the shape of e.g. "a0,b1\na1,b2"
    public String toString()
    {
    	String quiltString = "";
    	for(ArrayList<Piece> row : quilt)
    	{
    		for(Piece p: row)
    		{
    			String T = "" + p.getTexture();
    			String O = "" + p.getOrientation();
    			quiltString = quiltString + T + O + ",";
    		}
    		quiltString = quiltString.substring(0, quiltString.length()-1);
    		quiltString = quiltString + "\\n";
    	}
    	quiltString = quiltString.substring(0, quiltString.length()-2);
    	return quiltString;
    }
    
    //print quilt as a string of pieces in the shape of e.g. "a0,b1\na1,b2" to load into quilt objects
    public String toConsString()
    {
    	String quiltString = "";
    	for(ArrayList<Piece> row : quilt)
    	{
    		for(Piece p: row)
    		{
    			String T = "" + p.getTexture();
    			String O = "" + p.getOrientation();
    			quiltString = quiltString + T + O + ",";
    		}
    		quiltString = quiltString.substring(0, quiltString.length()-1);
    		quiltString = quiltString + "\n";
    	}
    	quiltString = quiltString.substring(0, quiltString.length()-1);
    	return quiltString;
    }
    
    //print quilt as a raw string of pieces in the shape of e.g. "a0b1a1b2" [with no "\n"]
    public String toRawString()
    {
    	String quiltString = "";
    	for(ArrayList<Piece> row : quilt)
    	{
    		for(Piece p: row)
    		{
    			String T = "" + p.getTexture();
    			String O = "" + p.getOrientation();
    			quiltString = quiltString + T + O;
    		}
    	}
    	return quiltString;
    }
    
    //piles main quilt on top of anotherQuilt
    public void pile(ArrayList<ArrayList<Piece>> anotherQuilt)
    {
    	for(ArrayList<Piece> row: anotherQuilt)
    	{
    		quilt.add(row);
    	}
    	update();
    }
    
    //sews main quilt and anotherQuilt together
    public void sew(ArrayList<ArrayList<Piece>> anotherQuilt)
    {
    	int i = 0;
    	for(ArrayList<Piece> row: anotherQuilt)
    	{
    		for(Piece p: row)
    		{
    			quilt.get(i).add(p);
    		}
    		i++;
    	}
    	update();
    }
    
    //pinWheels main quilt making it twice the size of rows and twice the size of columns,
    //and turn 90 degrees every new part of the quilt. 
    //Note: main quilt has to be square
    public void pinWheel()
    {
    	if (numRows != numColumns)
    	{
    		System.out.println("Error: Quilt is not of square size. PinWheel can only be used in square quilts.");
    	}
    	else 
    	{
    		turn();
        	ArrayList<ArrayList<Piece>> B = newQuilt(FromString(toConsString()));
        	unturn();
        	sew(B);
        	turn();
        	turn();
        	B = newQuilt(FromString(toConsString()));
        	unturn();
        	unturn();
        	pile(B);
    	}
    }
    
    //repeats main quilt m times the rows and n times the columns
    public void repeatBlock(int rows, int columns)
    {
    	ArrayList<ArrayList<Piece>> B = newQuilt(FromString(toConsString()));
    	for(int i=1;i<columns;i++)
    	{
    		sew(B);
    	}
    	
    	B = newQuilt(FromString(toConsString()));
    	for(int i=1;i<rows;i++)
    	{
    		pile(B);	
    	}
    	update();
    }
    
    //creates a checker board shape quilt by join main quilt to anotherQuilt
    //and repeating pattern m times the rows and n times the columns
    public void checkerBoard(ArrayList<ArrayList<Piece>> anotherQuilt, int rows, int columns)
    {
    	sew(anotherQuilt);
    	turn();
    	turn();
    	ArrayList<ArrayList<Piece>> B = newQuilt(FromString(toConsString()));
    	unturn();
    	unturn();
    	pile(B);
    	repeatBlock(rows/2,columns/2);
    }
}
