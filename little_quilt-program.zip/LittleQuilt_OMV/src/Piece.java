/**
 * A piece is a tuple consisting 
 * of a texture and an orientation.
 *
 * @author John Coleman
 */

public class Piece
{
    private String texture;
    private int orientation;
	
	public Piece(String t, int i)
	{
	     texture = t;
	     orientation = i;
	}
	
	public String getTexture() 
	{
		return texture;
	}
	
	public int getOrientation() 
	{
		return orientation;
	}
	
	public void setTexture(String t) 
	{
		texture = t;
	}
	
	public void setOrientation(int i)
	{
		orientation = i;
	}
	
	public Piece copy()
    {
        return new Piece(texture, orientation);
    }
	
	//a rotate method:
	//rotates piece 90 degrees clockwise
	public void rotate() 
	{
		orientation = (orientation + 1) % 4;
	}
	
	//override default toString method:
	public String toString()
	{
		return "(" + texture + "," + orientation + ")";
	}
	
}

