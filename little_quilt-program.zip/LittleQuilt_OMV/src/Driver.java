/**
 * Driver class for LittleQuilt project
 *
 * @author Oscar Martinez Vega
 * Project 2 - Little Quilt
 * Programming Languages
 * Fall 2022
 * Dr. John Coleman
 */

public class Driver
{
    public static void main(String args[])
    {
    	System.out.println("This a driver class to show the use of the main methods of LittleQuilt Project 2");
    	System.out.println();
    	
    	System.out.println("This is my quilt represented as an 2-dimensional ArrayList of Pieces:");
        Quilt my_quilt = new Quilt();
        my_quilt.FromPieces(my_quilt.FromString("a2,a2,a2,b0\na2,a2,b0,b0\na2,b0,b0,b0\nb0,b0,b0,b0"));
        System.out.println(my_quilt.getQuilt());
        System.out.println();
        
        System.out.println("This is my quilt loaded and printed through the TextQuilt class:");
        TextQuilt my_print = new TextQuilt();
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("This is my quilt represented as string of its pieces:");
        System.out.println(my_quilt.toString());
        System.out.println();
        
        System.out.println("This is my quilt printed after turning it 90 degrees:");
        my_quilt.turn();
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("This is my quilt printed after unturning it 90 degrees (original orientation):");
        my_quilt.unturn();
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("This pinWheels my quilt and prints it:");
        my_quilt.pinWheel();
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("This repeats my quilt m rows and n columns and prints it (in this case m=4, n=6):");
        my_quilt.repeatBlock(4,6);
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("Here I'm going to create another 2 quilt objects (my_quilt2 & my_quilt3):");
        Quilt my_quilt2 = new Quilt();
        my_quilt2.FromPieces(my_quilt2.FromString("a2,a2,a2,b0\na2,a2,b0,b0\na2,b0,b0,b0\nb0,b0,b0,b0"));
        my_quilt2.turn();
        my_quilt2.turn();
        my_quilt2.pinWheel();
        
        Quilt my_quilt3 = new Quilt();
        my_quilt3.FromPieces(my_quilt2.FromString("a2,a2,a2,b0\na2,a2,b0,b0\na2,b0,b0,b0\nb0,b0,b0,b0"));
        my_quilt3.pinWheel();
        
        System.out.println("This is my_quilt2:");
        System.out.println(my_print.quiltToText(my_quilt2));
        System.out.println();
        System.out.println("This is my_quilt3:");
        System.out.println(my_print.quiltToText(my_quilt3));
        System.out.println();
        
        System.out.println("This is a checkerBoard representation of size 4x6 of my_quilt2 & my_quilt3:");
        my_quilt2.checkerBoard(my_quilt3.getQuilt(),4,6);
        System.out.println(my_print.quiltToText(my_quilt2));
        System.out.println();
        
        System.out.println("This piles my_quilt & my_quilt2 together:");
        my_quilt.pile(my_quilt2.getQuilt());
        System.out.println(my_print.quiltToText(my_quilt));
        System.out.println();
        
        System.out.println("I will try to pinWheel my_quilt, but it'll fail because it's not of square size:");
        System.out.print("my_quilt rows: ");
        System.out.println(my_quilt.getRows());
        System.out.print("my_quilt columns: ");
        System.out.println(my_quilt.getColumns());
        my_quilt.pinWheel();
        System.out.println();
        
        System.out.println("That's all for my driver class :)");
        System.out.println("-Oscar Martinez Vega");
        }
    }

